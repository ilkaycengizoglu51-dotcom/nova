import { createHash } from 'node:crypto';
import { date, money } from './format';
export const fingerprint = (title: string, body: string, version: number) => createHash('sha256').update(`${title}\n${body}\nv${version}`).digest('hex');
export function contractTemplate(p: any, client: any, inst: any[]) {
  const total = inst.reduce((s, i) => s + Number(i.amount_kurus), 0);
  const plan = inst.length ? inst.map((i) => `${i.no}. taksit: ${date(i.due_date)} — ${money(i.amount_kurus)}${i.paid_at ? ' (ödendi)' : ''}`).join('\n') : 'Ödeme planı taraflarca ayrıca belirlenecektir.';
  return `PROJE HİZMET SÖZLEŞMESİ

Madde 1 — Taraflar
Bu sözleşme, NOVAPROJE Tarımsal Mühendislik (bundan sonra “NOVAPROJE”) ile ${client?.name || '[Danışan adı]'} (bundan sonra “Danışan”) arasında düzenlenmiştir.

Madde 2 — Konu
Sözleşmenin konusu, ${p.location || '[konum]'} adresindeki “${p.name}” (${p.type}) için mühendislik projelerinin hazırlanması ve ilgili danışmanlık hizmetlerinin verilmesidir.

Madde 3 — Kapsam
NOVAPROJE; vaziyet planı, mimari, statik, mekanik, elektrik ve yangın projeleri ile metraj ve keşif çalışmasını hazırlar. Kapsama girmeyen işler yazılı olarak ayrıca teklif edilir. Proje çıktıları DXF ve PDF olarak teslim edilir.

Madde 4 — Bedel ve ödeme
Sözleşme bedeli ${total ? money(total) : '[tutar]'} olup aşağıdaki plana göre ödenir:
${plan}
Vadesinde yapılmayan ödemeler, işin teslim takvimini aynı süre kadar erteleyebilir.

Madde 5 — Süre
İşe başlama tarihi ${date(p.start_date)}${p.target_date ? `, hedef teslim tarihi ${date(p.target_date)}` : ''}. Süreler, Danışan’dan beklenen belge ve onayların zamanında iletilmesine bağlıdır.

Madde 6 — Danışanın yükümlülükleri
Danışan; tapu, kimlik, ÇKS ve benzeri belgeleri NOVAPROJE danışan paneli üzerinden zamanında yükler, sahaya erişimi sağlar ve proje kararlarına ilişkin onaylarını panel üzerinden verir.

Madde 7 — Gizlilik
Taraflar, sözleşme kapsamında edindikleri bilgi ve belgeleri üçüncü kişilerle paylaşmaz. Kişisel veriler yalnızca bu sözleşmenin ifası amacıyla işlenir.

Madde 8 — Fikri mülkiyet
Bedelin tamamı ödendiğinde, proje çıktılarının bu proje için kullanım hakkı Danışan’a geçer.

Madde 9 — Fesih
Taraflardan biri yükümlülüklerini yerine getirmezse, diğer taraf yazılı bildirimle sözleşmeyi feshedebilir. Fesih tarihine kadar yapılan işlerin bedeli ödenir.

Madde 10 — Elektronik onay
Taraflar, bu sözleşmenin NOVAPROJE danışan paneli üzerinden elektronik olarak onaylanmasını ve onay kayıtlarının (tarih, saat, IP adresi, belge parmak izi) delil olarak kullanılmasını kabul eder.

Madde 11 — Uyuşmazlık
Bu sözleşmeden doğan uyuşmazlıklarda [şehir] mahkemeleri ve icra daireleri yetkilidir.`;
}
