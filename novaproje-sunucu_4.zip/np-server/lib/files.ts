import { one } from './db';
export const MAX_FILE = 10 * 1024 * 1024;
export const OK_TYPES = ['application/pdf', 'image/jpeg', 'image/png', 'image/webp', 'image/svg+xml'];
/** Validates and stores an uploaded File in the database; returns its id. */
export async function saveFile(f: File, opts: { clientId?: number | null; uploadedBy: number; isPublic?: boolean; images?: boolean }) {
  if (!f || typeof f === 'string' || !f.size) return null;
  const allowed = opts.images ? ['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml'] : OK_TYPES.filter((t) => t !== 'image/svg+xml');
  if (!allowed.includes(f.type)) throw new Error(`${f.name}: yalnızca ${opts.images ? 'PNG, JPG, WebP veya SVG' : 'PDF, JPG, PNG veya WebP'} yüklenebilir.`);
  if (f.size > MAX_FILE) throw new Error(`${f.name}: dosya 10 MB’tan büyük.`);
  const buf = Buffer.from(await f.arrayBuffer());
  const r = await one<{ id: string }>('INSERT INTO files (name, mime, size, data, client_id, public, uploaded_by) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id',
    [f.name.slice(0, 200), f.type, f.size, buf, opts.clientId ?? null, !!opts.isPublic, opts.uploadedBy]);
  return r?.id ?? null;
}
