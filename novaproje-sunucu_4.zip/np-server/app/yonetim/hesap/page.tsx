import PasswordForm from '@/components/PasswordForm';
import { PageTitle } from '@/components/Shell';
export default function Account() { return <><PageTitle title="Hesabım" /><PasswordForm /></>; }
