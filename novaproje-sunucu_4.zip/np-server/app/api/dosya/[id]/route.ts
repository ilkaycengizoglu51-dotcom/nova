import { NextResponse } from 'next/server';
import { one } from '@/lib/db';
import { getUser } from '@/lib/auth';

export async function GET(req: Request, { params }: { params: { id: string } }) {
  if (!/^[0-9a-f-]{36}$/i.test(params.id)) return new NextResponse('Bulunamadı', { status: 404 });
  const f = await one('SELECT name, mime, size, data, client_id, public FROM files WHERE id = $1', [params.id]);
  if (!f) return new NextResponse('Bulunamadı', { status: 404 });
  if (!f.public) { const u = await getUser(); if (!u || (u.role !== 'admin' && f.client_id !== u.id)) return new NextResponse('Yetkiniz yok', { status: 403 }); }
  const dl = new URL(req.url).searchParams.has('indir');
  return new NextResponse(f.data, { headers: {
    'Content-Type': f.mime, 'Content-Length': String(f.size),
    'Content-Disposition': `${dl ? 'attachment' : 'inline'}; filename*=UTF-8''${encodeURIComponent(f.name)}`,
    'Cache-Control': f.public ? 'public, max-age=86400' : 'private, no-store',
    ...(f.mime === 'image/svg+xml' ? { 'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'" } : {}),
  } });
}
